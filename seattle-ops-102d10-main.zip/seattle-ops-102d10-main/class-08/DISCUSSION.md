# Readings: Virtualization of Windows OS

Below you will find some reading materials and videos that support today's topic and the upcoming lecture.

## Reading

[What is an ISO file?](https://www.lifewire.com/iso-file-2625923){:target="_blank"}: Only read sections 1.1 - 1.4 inclusively.

1. What is an ISO File?
1. How do you write an ISO file to a CD, DVD, or removable media (like a thumb drive)?
1. How do you create an ISO file?
1. How do you mount an ISO file?
