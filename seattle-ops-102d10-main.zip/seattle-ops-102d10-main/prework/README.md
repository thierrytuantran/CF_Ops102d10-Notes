# Prework - Ops 102: Intro to Computer Operations

This is the mandatory prework for Ops 102. A few days prior to the course start date, you will be invited to an online Learning Management System where you can confirm that you've completed this prework by submitting each below assignment.

Start on the prework as soon as you can and be sure to allow yourself plenty of time to complete it.

> **Note: All prework is due before start of first class**

## Complete Prework Assignment

1. [Obtain your Ops Lab Kit](https://codefellows.github.io/common_curriculum/prework/computer-setup-ops)
1. [Setup Your Accounts](https://codefellows.github.io/common_curriculum/prework/setup-your-accounts)
