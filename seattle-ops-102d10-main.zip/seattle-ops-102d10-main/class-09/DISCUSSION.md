# Readings: Command Line Interface

Below you will find some reading materials and videos that support today's topic and the upcoming lecture.

## Reading

[Command Prompt: What it is and how to use it](https://www.lifewire.com/command-prompt-2625840){:target="_blank"}

1. What is the Command Prompt?
1. How do I access the Command Prompt?
1. What are some of the most commonly used commands?
1. What is Windows Power Shell?
1. What is Windows Terminal?
  
