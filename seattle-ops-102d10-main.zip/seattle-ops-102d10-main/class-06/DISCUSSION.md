# Readings: SOHO Networking

Below you will find reading materials and videos that support today's topic and the upcoming lecture.

## Reading

Fascinating history: What one home router can do - [The WRT54GL](https://arstechnica.com/information-technology/2016/07/the-wrt54gl-a-54mbps-router-from-2005-still-makes-millions-for-linksys/){:target="_blank"}

1. What makes the Linksys WRT54GL famous?
1. Given it's age, why do people continue to buy the Linksys WRT54GL?
1. What does the "WRT54GL" stand for in the name?
1. What did Linksys sell before routers?
1. When did Linksys preview their first consumer router?
1. Who suggested to name it a "router"?
1. What happened when Cisco replaced the Linux-based firmware with the VxWorks platform?
1. Why doesn't the WRT54GL model need to be modified to abide by the new FCC rules?
1. Does the WRT54GL model still get updates from Linksys?
